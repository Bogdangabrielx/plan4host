import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

type VEvent = {
  uid: string | null;
  summary: string | null;
  dtstart: string; // raw ICS value
  dtend: string;   // raw ICS value
};

function parseICS(ics: string): VEvent[] {
  // Minimal parser: caută blocuri VEVENT și ia UID/DTSTART/DTEND/SUMMARY
  const out: VEvent[] = [];
  const blocks = ics.split(/BEGIN:VEVENT/i).slice(1);
  for (const block of blocks) {
    const seg = block.split(/END:VEVENT/i)[0];
    const get = (name: string) => {
      const m = seg.match(new RegExp(`\\n${name}(;[^:\\n]*)?:(.+)`, "i"));
      return m ? m[2].trim() : null;
    };
    const uid = get("UID");
    const sum = get("SUMMARY");
    const dtstart = get("DTSTART") || "";
    const dtend = get("DTEND") || "";
    if (dtstart && dtend) out.push({ uid, summary: sum, dtstart, dtend });
  }
  return out;
}

function fromICSDate(v: string, fallbackTime: string): { date: string; time: string | null } {
  // Acceptă: YYYYMMDD (all-day) sau YYYYMMDDTHHMMSSZ / local fără Z
  const mDate = v.match(/^(\d{4})(\d{2})(\d{2})$/);
  if (mDate) {
    const date = `${mDate[1]}-${mDate[2]}-${mDate[3]}`;
    return { date, time: fallbackTime || null };
  }
  const mDateTime = v.match(/^(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})(\d{2})(Z)?$/);
  if (mDateTime) {
    const date = `${mDateTime[1]}-${mDateTime[2]}-${mDateTime[3]}`;
    const time = `${mDateTime[4]}:${mDateTime[5]}`;
    return { date, time };
  }
  // fallback extrem
  const iso = v.replace(/Z$/,"");
  const d = new Date(iso);
  const date = `${d.getUTCFullYear()}-${String(d.getUTCMonth()+1).padStart(2,"0")}-${String(d.getUTCDate()).padStart(2,"0")}`;
  const time = `${String(d.getUTCHours()).padStart(2,"0")}:${String(d.getUTCMinutes()).padStart(2,"0")}`;
  return { date, time };
}

export async function POST(req: Request) {
  const supabase = createClient();
  const { integrationId } = await req.json().catch(() => ({}));
  if (!integrationId) return NextResponse.json({ error: "integrationId required" }, { status: 400 });

  // load integration + type + property defaults
  const integ = await supabase
    .from("ical_type_integrations")
    .select("id,property_id,room_type_id,provider,url,is_active,room_types(name),properties(check_in_time,check_out_time)")
    .eq("id", integrationId).maybeSingle();

  if (integ.error || !integ.data) return NextResponse.json({ error: "integration not found" }, { status: 404 });
  if (!integ.data.is_active) return NextResponse.json({ error: "integration inactive" }, { status: 400 });

  const checkIn = integ.data.properties?.check_in_time || "14:00";
  const checkOut = integ.data.properties?.check_out_time || "11:00";

  const started = await supabase.from("ical_type_sync_logs").insert({ integration_id: integrationId }).select().maybeSingle();
  const logId = started.data?.id;

  try {
    // fetch ICS
    const r = await fetch(integ.data.url, { cache: "no-store" });
    if (!r.ok) throw new Error(`Fetch failed: ${r.status}`);
    const ics = await r.text();

    const events = parseICS(ics);

    // load rooms of this type
    const rRooms = await supabase.from("rooms").select("id").eq("room_type_id", integ.data.room_type_id);
    const rooms = (rRooms.data ?? []).map(r => r.id);
    if (rooms.length === 0) throw new Error("No rooms in this type.");

    // load existing bookings for these rooms (window +- 2y)
    const today = new Date();
    const yMin = `${today.getFullYear()-2}-01-01`;
    const yMax = `${today.getFullYear()+2}-12-31`;
    const rBookings = await supabase
      .from("bookings")
      .select("id,room_id,start_date,end_date,start_time,end_time,status")
      .in("room_id", rooms)
      .gte("start_date", yMin)
      .lte("end_date", yMax)
      .neq("status","cancelled");

    const bookings = (rBookings.data ?? []);

    // helper: test overlap
    function overlaps(aS: string, aSt: string | null, aE: string, aEt: string | null, bS: string, bSt: string | null, bE: string, bEt: string | null) {
      const aStart = new Date(`${aS}T${(aSt ?? checkIn)}:00Z`).getTime();
      const aEnd   = new Date(`${aE}T${(aEt ?? checkOut)}:00Z`).getTime();
      const bStart = new Date(`${bS}T${(bSt ?? checkIn)}:00Z`).getTime();
      const bEnd   = new Date(`${bE}T${(bEt ?? checkOut)}:00Z`).getTime();
      return aStart < bEnd && bStart < aEnd;
    }

    // current UID map
    const rMap = await supabase
      .from("ical_uid_map")
      .select("id,uid,room_id,booking_id")
      .eq("property_id", integ.data.property_id);

    const uidMap = new Map<string, {id: string; room_id: string | null; booking_id: string | null}>();
    for (const row of (rMap.data ?? [])) uidMap.set(row.uid, row);

    let added = 0, updated = 0, conflicts = 0;

    for (const ev of events) {
      const uid = ev.uid ?? "";
      const s = fromICSDate(ev.dtstart, checkIn);
      const e = fromICSDate(ev.dtend,   checkOut);

      if (uidMap.has(uid) && uid) {
        // update existing booking times if changed
        const map = uidMap.get(uid)!;
        if (map.booking_id) {
          const upd = await supabase.from("bookings").update({
            start_date: s.date, start_time: s.time,
            end_date:   e.date, end_time:   e.time,
          }).eq("id", map.booking_id);
          if (!upd.error) updated++;
        }
        await supabase.from("ical_uid_map").update({
          start_date: s.date, end_date: e.date, start_time: s.time ?? null, end_time: e.time ?? null, last_seen: new Date().toISOString()
        }).eq("id", map.id);
        continue;
      }

      // assign a free room determinist: prima cameră care nu are overlap
      let chosenRoom: string | null = null;
      for (const rid of rooms) {
        const has = bookings.some(b => b.room_id === rid && overlaps(b.start_date, b.start_time, b.end_date, b.end_time, s.date, s.time, e.date, e.time));
        if (!has) { chosenRoom = rid; break; }
      }

      if (!chosenRoom) {
        conflicts++;
        await supabase.from("ical_unassigned_events").insert({
          property_id: integ.data.property_id,
          room_type_id: integ.data.room_type_id,
          uid: uid || null,
          summary: ev.summary,
          start_date: s.date,
          end_date: e.date,
          start_time: s.time ?? null,
          end_time: e.time ?? null,
          payload: JSON.stringify(ev)
        });
        continue;
      }

      // create booking
      const ins = await supabase.from("bookings").insert({
        property_id: integ.data.property_id,
        room_id: chosenRoom,
        start_date: s.date, end_date: e.date,
        start_time: s.time ?? null, end_time: e.time ?? null,
        status: "confirmed"
      }).select().maybeSingle();

      if (!ins.error && ins.data) {
        added++;
        await supabase.from("ical_uid_map").insert({
          property_id: integ.data.property_id,
          room_type_id: integ.data.room_type_id,
          room_id: chosenRoom,
          booking_id: ins.data.id,
          uid: uid || `${ins.data.id}@no-uid`,
          source: integ.data.provider,
          start_date: s.date, end_date: e.date, start_time: s.time ?? null, end_time: e.time ?? null
        });
        bookings.push(ins.data); // include în memorie pt. următoarele alocări
      }
    }

    await supabase.from("ical_type_integrations").update({ last_sync: new Date().toISOString() }).eq("id", integrationId);
    if (logId) await supabase.from("ical_type_sync_logs").update({
      finished_at: new Date().toISOString(), status: "ok", added_count: added, updated_count: updated, conflicts
    }).eq("id", logId);

    return NextResponse.json({ ok: true, added, updated, conflicts });
  } catch (e: any) {
    if (logId) await supabase.from("ical_type_sync_logs").update({
      finished_at: new Date().toISOString(), status: "error", error_message: String(e?.message ?? e)
    }).eq("id", logId);
    return NextResponse.json({ error: String(e?.message ?? e) }, { status: 500 });
  }
}
