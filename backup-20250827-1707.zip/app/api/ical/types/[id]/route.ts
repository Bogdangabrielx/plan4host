import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

/* ---------- helpers ---------- */
function fmtStampUTC(d = new Date()) {
  const pad = (n: number) => String(n).padStart(2, "0");
  return (
    d.getUTCFullYear().toString() +
    pad(d.getUTCMonth() + 1) +
    pad(d.getUTCDate()) +
    "T" +
    pad(d.getUTCHours()) +
    pad(d.getUTCMinutes()) +
    pad(d.getUTCSeconds()) +
    "Z"
  );
}
function addDaysStr(s: string, n: number) {
  const [y, m, d] = s.split("-").map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  dt.setUTCDate(dt.getUTCDate() + n);
  const pad = (x: number) => String(x).padStart(2, "0");
  return `${dt.getUTCFullYear()}-${pad(dt.getUTCMonth() + 1)}-${pad(dt.getUTCDate())}`;
}
function dateToIcsDate(s: string) {
  const [y, m, d] = s.split("-");
  return `${y}${m}${d}`;
}
function icsEscape(text: string) {
  return (text || "")
    .replace(/\\/g, "\\\\").replace(/;/g, "\\;").replace(/,/g, "\\,").replace(/\r?\n/g, "\\n");
}
function okIcs(body: string) {
  return new NextResponse(body, {
    status: 200,
    headers: {
      "Content-Type": "text/calendar; charset=utf-8",
      "Cache-Control": "no-cache",
    },
  });
}
function bad(msg: string, code = 400) {
  return new NextResponse(msg, { status: code });
}
function buildVTZ(tzid: string) {
  if (tzid === "Europe/Bucharest") {
    return [
      "BEGIN:VTIMEZONE",
      "TZID:Europe/Bucharest",
      "X-LIC-LOCATION:Europe/Bucharest",
      "BEGIN:DAYLIGHT",
      "TZOFFSETFROM:+0200",
      "TZOFFSETTO:+0300",
      "TZNAME:EEST",
      "DTSTART:19700329T030000",
      "RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU",
      "END:DAYLIGHT",
      "BEGIN:STANDARD",
      "TZOFFSETFROM:+0300",
      "TZOFFSETTO:+0200",
      "TZNAME:EET",
      "DTSTART:19701025T040000",
      "RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU",
      "END:STANDARD",
      "END:VTIMEZONE",
    ].join("\r\n");
  }
  return `BEGIN:VTIMEZONE\r\nTZID:${tzid}\r\nEND:VTIMEZONE`;
}
function compressDates(sortedDates: string[]) {
  const ranges: Array<{ start: string; end: string }> = [];
  if (sortedDates.length === 0) return ranges;
  let start = sortedDates[0];
  let prev = start;
  for (let i = 1; i < sortedDates.length; i++) {
    const d = sortedDates[i];
    if (d === addDaysStr(prev, 1)) { prev = d; continue; }
    ranges.push({ start, end: addDaysStr(prev, 1) });
    start = prev = d;
  }
  ranges.push({ start, end: addDaysStr(prev, 1) });
  return ranges;
}

/* ---------- route ---------- */
export async function GET(req: NextRequest, ctx: { params: { id: string } }) {
  try {
    const supabase = createClient();

    // Suport și pentru sufix .ics
    const raw = ctx.params.id || "";
    theId: {
    }
    const typeId = raw.endsWith(".ics") ? raw.slice(0, -4) : raw;

    // Orizont implicit: -1y .. +2y
    const { searchParams } = new URL(req.url);
    const from = searchParams.get("from");
    const to = searchParams.get("to");
    const today = new Date();
    const iso = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    const fromDefault = new Date(today); fromDefault.setFullYear(today.getFullYear() - 1);
    const toDefault   = new Date(today); toDefault.setFullYear(today.getFullYear() + 2);
    const fromStr = from || iso(fromDefault);
    const toStr   = to   || iso(toDefault);

    // Tipul + proprietate (timezone)
    const { data: typeRow, error: eType } = await supabase
      .from("room_types").select("id,property_id,name").eq("id", typeId).single();
    if (eType || !typeRow) return bad("Room type not found", 404);

    const { data: prop, error: eProp } = await supabase
      .from("properties").select("timezone").eq("id", typeRow.property_id).single();
    if (eProp || !prop) return bad("Property not found", 404);

    // ❗ Enforce timezone
    if (!prop.timezone) {
      return bad("Timezone not set for this property. Please set Country (timezone) in Dashboard and retry.", 400);
    }
    const TZID = prop.timezone;

    // Camere din tip
    const { data: rooms, error: eRooms } = await supabase
      .from("rooms").select("id").eq("room_type_id", typeRow.id);
    if (eRooms) return bad("Failed to load rooms", 500);

    const roomIds = (rooms || []).map(r => r.id);
    const capacity = roomIds.length;

    // Header calendar
    const lines: string[] = [];
    lines.push("BEGIN:VCALENDAR");
    lines.push("VERSION:2.0");
    lines.push("PRODID:-//plan4host//ical//EN");
    lines.push("CALSCALE:GREGORIAN");
    lines.push("METHOD:PUBLISH");
    lines.push(`X-WR-CALNAME:${icsEscape(`${typeRow.name} Sold-out (Plan4Host)`)}`);
    lines.push(`X-WR-TIMEZONE:${TZID}`);
    lines.push(buildVTZ(TZID));

    if (capacity === 0) {
      lines.push("END:VCALENDAR");
      return okIcs(lines.join("\r\n"));
    }

    // Rezervări din orizont pentru camerele tipului (excludem cancelled)
    const { data: bookings, error: eBk } = await supabase
      .from("bookings")
      .select("id,room_id,start_date,end_date,status")
      .in("room_id", roomIds)
      .neq("status", "cancelled")
      .lte("start_date", toStr)
      .gte("end_date", fromStr)
      .order("start_date", { ascending: true });
    if (eBk) return bad("Failed to load bookings", 500);

    // Numărăm nopțile ocupate
    const counts = new Map<string, number>();
    const inc = (day: string) => counts.set(day, (counts.get(day) || 0) + 1);

    function addDays(s: string, n: number) {
      const [y, m, d] = s.split("-").map(Number);
      const dt = new Date(Date.UTC(y, m - 1, d));
      dt.setUTCDate(dt.getUTCDate() + n);
      const pad = (x: number) => String(x).padStart(2, "0");
      return `${dt.getUTCFullYear()}-${pad(dt.getUTCMonth() + 1)}-${pad(dt.getUTCDate())}`;
    }

    for (const b of bookings || []) {
      let d = b.start_date;
      while (d < b.end_date) {
        if (!(d < fromStr) && !(d > toStr)) inc(d);
        d = addDays(d, 1);
      }
    }

    // Zile sold-out
    const soldOut: string[] = [];
    for (const [day, c] of counts.entries()) if (c >= capacity) soldOut.push(day);
    soldOut.sort();

    // Grupăm în intervale all-day
    const ranges = compressDates(soldOut);
    const dtstamp = fmtStampUTC();

    for (const r of ranges) {
      lines.push("BEGIN:VEVENT");
      lines.push(`UID:${typeRow.id}-${r.start}@plan4host`);
      lines.push(`DTSTAMP:${dtstamp}`);
      lines.push(`SUMMARY:${icsEscape(`Sold out (${typeRow.name})`)}`);
      lines.push(`STATUS:CONFIRMED`);
      lines.push(`DTSTART;VALUE=DATE:${dateToIcsDate(r.start)}`);
      lines.push(`DTEND;VALUE=DATE:${dateToIcsDate(r.end)}`); // end exclusiv
      lines.push("END:VEVENT");
    }

    lines.push("END:VCALENDAR");
    return okIcs(lines.join("\r\n"));
  } catch {
    return bad("Unexpected error", 500);
  }
}
