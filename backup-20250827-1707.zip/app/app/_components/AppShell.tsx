"use client";

import AppHeader from "../ui/AppHeader";
import { HeaderProvider } from "./HeaderContext";

export default function AppShell({
  children,
  currentPath,
  initialTitle = "",
  initialPill = null,
  initialRight = null,
}: {
  children: React.ReactNode;
  currentPath?: string;
  initialTitle?: string;
  initialPill?: React.ReactNode | null;
  initialRight?: React.ReactNode | null;
}) {
  return (
    <HeaderProvider initialTitle={initialTitle} initialPill={initialPill} initialRight={initialRight}>
      <div style={{ minHeight: "100vh", background: "var(--bg)", color: "var(--text)" }}>
        <AppHeader currentPath={currentPath} />
        <main style={{ padding: 16, display: "grid", gap: 16, maxWidth: 1200, margin: "0 auto" }}>
          {children}
        </main>
      </div>
    </HeaderProvider>
  );
}
