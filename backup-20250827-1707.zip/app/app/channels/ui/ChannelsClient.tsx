"use client";

import { useEffect, useMemo, useState } from "react";
import { createClient } from "@/lib/supabase/client";

/** DB types */
type Property = { id: string; name: string; timezone: string | null };
type Room = { id: string; name: string; property_id: string; room_type_id: string | null };
type RoomType = { id: string; name: string; property_id: string };
type TypeIntegration = {
  id: string;
  property_id: string;
  room_type_id: string;
  provider: string | null;
  url: string;
  is_active: boolean | null;
  last_sync: string | null;
};

export default function ChannelsClient({ initialProperties }: { initialProperties: Property[] }) {
  const supabase = useMemo(() => createClient(), []);
  const [status, setStatus] = useState<"Idle" | "Loading" | "Saving…" | "Error">("Idle");

  const [properties] = useState<Property[]>(initialProperties);
  const [propertyId, setPropertyId] = useState<string>(initialProperties[0]?.id ?? "");
  const [timezone, setTimezone] = useState<string>(initialProperties[0]?.timezone ?? "");

  const [rooms, setRooms] = useState<Room[]>([]);
  const [types, setTypes] = useState<RoomType[]>([]);
  const [integrations, setIntegrations] = useState<TypeIntegration[]>([]);

  const [origin, setOrigin] = useState<string>("");
  useEffect(() => { setOrigin(window.location.origin); }, []);

  // top-level modals (A/B/C)
  const [showRoomsModal, setShowRoomsModal] = useState(false);
  const [showTypesModal, setShowTypesModal] = useState(false);
  const [showImportModal, setShowImportModal] = useState(false);

  // inner modals (detaliu element)
  const [activeRoomId, setActiveRoomId] = useState<string | null>(null);
  const [activeTypeId, setActiveTypeId] = useState<string | null>(null);
  const [manageTypeId, setManageTypeId] = useState<string | null>(null);

  useEffect(() => {
    if (!propertyId) return;
    setStatus("Loading");
    (async () => {
      const [rProp, rRooms, rTypes, rInteg] = await Promise.all([
        supabase.from("properties").select("id,timezone").eq("id", propertyId).single(),
        supabase.from("rooms")
          .select("id,name,property_id,room_type_id")
          .eq("property_id", propertyId)
          .order("sort_index", { ascending: true })
          .order("created_at", { ascending: true }),
        supabase.from("room_types")
          .select("id,name,property_id")
          .eq("property_id", propertyId)
          .order("name", { ascending: true }),
        supabase.from("ical_type_integrations")
          .select("id,property_id,room_type_id,provider,url,is_active,last_sync")
          .eq("property_id", propertyId)
          .order("created_at", { ascending: true }),
      ]);
      if (rProp.error || rRooms.error || rTypes.error || rInteg.error) { setStatus("Error"); return; }
      setTimezone(rProp.data?.timezone || "");
      setRooms((rRooms.data ?? []) as Room[]);
      setTypes((rTypes.data ?? []) as RoomType[]);
      setIntegrations((rInteg.data ?? []) as TypeIntegration[]);
      setStatus("Idle");
    })();
  }, [propertyId, supabase]);

  /* URLs & helpers */
  function roomIcsUrl(id: string) { return `${origin}/api/ical/rooms/${id}.ics`; }
  function typeIcsUrl(id: string) { return `${origin}/api/ical/types/${id}.ics`; }
  async function copy(text: string) { try { await navigator.clipboard.writeText(text); } catch {} }

  /* Integrations CRUD (Import per TYPE) */
  async function addIntegration(roomTypeId: string, provider: string, url: string) {
    if (!propertyId || !roomTypeId || !url.trim()) return;
    setStatus("Saving…");
    const { data, error } = await supabase
      .from("ical_type_integrations")
      .insert({ property_id: propertyId, room_type_id: roomTypeId, provider: provider || null, url: url.trim(), is_active: true })
      .select("id,property_id,room_type_id,provider,url,is_active,last_sync")
      .single();
    if (!error && data) setIntegrations(prev => [...prev, data as TypeIntegration]);
    setStatus(error ? "Error" : "Idle");
  }
  async function deleteIntegration(id: string) {
    setStatus("Saving…");
    const { error } = await supabase.from("ical_type_integrations").delete().eq("id", id);
    if (!error) setIntegrations(prev => prev.filter(x => x.id !== id));
    setStatus(error ? "Error" : "Idle");
  }
  async function toggleActive(integration: TypeIntegration) {
    setStatus("Saving…");
    const next = !integration.is_active;
    const { error, data } = await supabase
      .from("ical_type_integrations")
      .update({ is_active: next })
      .eq("id", integration.id)
      .select("id,property_id,room_type_id,provider,url,is_active,last_sync")
      .single();
    if (!error && data) setIntegrations(prev => prev.map(x => x.id === integration.id ? (data as TypeIntegration) : x));
    setStatus(error ? "Error" : "Idle");
  }
  async function syncNow(integrationId: string) {
    try {
      setStatus("Saving…");
      const res = await fetch("/api/ical/sync", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ integrationId }),
      });
      if (!res.ok) throw new Error("Sync failed");
      setIntegrations(prev => prev.map(x => x.id === integrationId ? { ...x, last_sync: new Date().toISOString() } : x));
      setStatus("Idle");
    } catch {
      setStatus("Error");
    }
  }

  /* UI */
  const pillLabel =
    status === "Error" ? "Error" :
    status === "Loading" || status === "Saving…" ? "Syncing…" : "Idle";

  return (
    <div>
      {/* mic toolbar local: pill + property select */}
      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 12, flexWrap: "wrap" }}>
        <span style={miniPill}>{pillLabel}</span>
        <span style={miniPill}>All times in {timezone || "—"}</span>
        <div style={{ marginLeft: "auto" }}>
          <select value={propertyId} onChange={(e) => setPropertyId(e.target.value)} style={select}>
            {properties.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
          </select>
        </div>
      </div>

      {/* Card cu acțiuni */}
      <section style={panel}>
        <h3 style={{ marginTop: 0 }}>Channels & iCal</h3>
        {!timezone && (
          <p style={{ color: "var(--danger)", marginTop: 0 }}>
            Set Country (timezone) in Dashboard to produce valid .ics files.
          </p>
        )}
        <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
          <button style={primaryBtn} onClick={() => setShowRoomsModal(true)}>Export per ROOM</button>
          <button style={ghostBtn} onClick={() => setShowTypesModal(true)}>Export per TYPE</button>
          <button style={ghostBtn} onClick={() => setShowImportModal(true)}>Import</button>
        </div>
      </section>

      {/* ======= MODAL A: EXPORT per ROOM ======= */}
      {showRoomsModal && (
        <Modal title="Export per ROOM" onClose={() => { setShowRoomsModal(false); setActiveRoomId(null); }}>
          <div style={blueGrid}>
            {rooms.length === 0 ? (
              <p style={{ color: "#0c111b", gridColumn: "1 / -1" }}>No rooms in this property.</p>
            ) : rooms.map(r => (
              <button
                key={r.id}
                onClick={() => setActiveRoomId(r.id)}
                style={blueTile}
                title={r.name}
              >
                <span style={tileTitle}>{r.name}</span>
                <span style={tileSub}>Open details</span>
              </button>
            ))}
          </div>

          {activeRoomId && (() => {
            const room = rooms.find(x => x.id === activeRoomId)!;
            const url = roomIcsUrl(activeRoomId);
            return (
              <InnerModal title={room.name} onClose={() => setActiveRoomId(null)}>
                <div style={{ display: "grid", gap: 8 }}>
                  <small style={{ color: "var(--muted)", wordBreak: "break-all" }}>{url}</small>
                  <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                    <button style={ghostBtn} onClick={() => copy(url)}>Copy URL</button>
                    <a style={ghostBtn} href={url} target="_blank" rel="noreferrer">Open</a>
                  </div>
                  <p style={{ color: "var(--muted)", margin: 0 }}>
                    Use this link if your OTA uses separate listings per room, or for your personal calendar (Google/Apple/Outlook).
                  </p>
                </div>
              </InnerModal>
            );
          })()}
        </Modal>
      )}

      {/* ======= MODAL B: EXPORT per TYPE (fără mențiunea “sold-out” în UI) ======= */}
      {showTypesModal && (
        <Modal title="Export per TYPE" onClose={() => { setShowTypesModal(false); setActiveTypeId(null); }}>
          <div style={blueGrid}>
            {types.length === 0 ? (
              <p style={{ color: "#0c111b", gridColumn: "1 / -1" }}>No room types defined.</p>
            ) : types.map(t => (
              <button
                key={t.id}
                onClick={() => setActiveTypeId(t.id)}
                style={blueTile}
                title={t.name}
              >
                <span style={tileTitle}>{t.name}</span>
                <span style={tileSub}>Open details</span>
              </button>
            ))}
          </div>

          {activeTypeId && (() => {
            const t = types.find(x => x.id === activeTypeId)!;
            const url = typeIcsUrl(activeTypeId);
            return (
              <InnerModal title={t.name} onClose={() => setActiveTypeId(null)}>
                <div style={{ display: "grid", gap: 8 }}>
                  <small style={{ color: "var(--muted)", wordBreak: "break-all" }}>{url}</small>
                  <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                    <button style={ghostBtn} onClick={() => copy(url)}>Copy URL</button>
                    <a style={ghostBtn} href={url} target="_blank" rel="noreferrer">Open</a>
                  </div>
                  <p style={{ color: "var(--muted)", margin: 0 }}>
                    Add this URL to your OTA room-type listing.
                  </p>
                </div>
              </InnerModal>
            );
          })()}
        </Modal>
      )}

      {/* ======= MODAL C: IMPORT (pe TYPE) ======= */}
      {showImportModal && (
        <Modal title="Import (per TYPE)" onClose={() => { setShowImportModal(false); setManageTypeId(null); }}>
          <div style={blueGrid}>
            {types.length === 0 ? (
              <p style={{ color: "#0c111b", gridColumn: "1 / -1" }}>No room types defined.</p>
            ) : types.map(t => (
              <button
                key={t.id}
                onClick={() => setManageTypeId(t.id)}
                style={blueTile}
                title={`Manage ${t.name}`}
              >
                <span style={tileTitle}>{t.name}</span>
                <span style={tileSub}>Manage feeds</span>
              </button>
            ))}
          </div>

          {manageTypeId && (
            <ManageTypeModal
              timezone={timezone}
              integrations={integrations.filter(i => i.room_type_id === manageTypeId)}
              onClose={() => setManageTypeId(null)}
              onAdd={(provider, url) => addIntegration(manageTypeId, provider, url)}
              onDelete={(id) => deleteIntegration(id)}
              onToggle={(ii) => toggleActive(ii)}
              onSync={(id) => syncNow(id)}
            />
          )}
        </Modal>
      )}
    </div>
  );
}

/* ======= UI helpers & components ======= */

function Modal({ title, children, onClose }:{
  title: string; children: React.ReactNode; onClose: () => void;
}) {
  return (
    <div
      role="dialog" aria-modal="true" onClick={onClose}
      style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.6)", zIndex: 40, display: "grid", placeItems: "center", padding: 12 }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{ background: "var(--panel)", border: "1px solid var(--border)", borderRadius: 12, padding: 16, width: "min(980px, 96vw)" }}
      >
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 8 }}>
          <h3 style={{ margin: 0 }}>{title}</h3>
          <button style={ghostBtn} onClick={onClose}>Close</button>
        </div>
        {children}
      </div>
    </div>
  );
}

function InnerModal({ title, children, onClose }:{
  title: string; children: React.ReactNode; onClose: () => void;
}) {
  return (
    <div
      role="dialog" aria-modal="true" onClick={onClose}
      style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.65)", zIndex: 50, display: "grid", placeItems: "center", padding: 12 }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{ background: "var(--panel)", border: "1px solid var(--border)", borderRadius: 12, padding: 16, width: "min(720px, 94vw)" }}
      >
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 8 }}>
          <h3 style={{ margin: 0 }}>{title}</h3>
          <button style={ghostBtn} onClick={onClose}>Close</button>
        </div>
        {children}
      </div>
    </div>
  );
}

function ManageTypeModal({
  timezone, integrations, onClose, onAdd, onDelete, onToggle, onSync
}:{
  timezone: string | null;
  integrations: { id: string; provider: string | null; url: string; is_active: boolean | null; last_sync: string | null; }[];
  onClose: () => void;
  onAdd: (provider: string, url: string) => void;
  onDelete: (id: string) => void;
  onToggle: (ii: any) => void;
  onSync: (id: string) => void;
}) {
  const [provider, setProvider] = useState("Booking");
  const [url, setUrl] = useState("");

  return (
    <InnerModal title="Manage imports for room type" onClose={onClose}>
      <p style={{ color: "var(--muted)", marginTop: 0 }}>
        Times interpreted in <strong>{timezone || "—"}</strong>.
      </p>

      <div style={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 12, padding: 12, marginBottom: 12 }}>
        <div style={{ display: "grid", gap: 8 }}>
          <div style={{ display: "grid", gap: 6 }}>
            <label style={label}>Provider</label>
            <select style={select} value={provider} onChange={(e) => setProvider((e.target as HTMLSelectElement).value)}>
              <option>Booking</option>
              <option>Airbnb</option>
              <option>Expedia</option>
              <option>Other</option>
            </select>
          </div>
          <div style={{ display: "grid", gap: 6 }}>
            <label style={label}>iCal URL</label>
            <input style={input} value={url} onChange={(e) => setUrl((e.target as HTMLInputElement).value)} placeholder="https://..." />
          </div>
          <div>
            <button style={primaryBtn} onClick={() => { if (url.trim()) { onAdd(provider, url); setUrl(""); } }}>
              Add feed
            </button>
          </div>
        </div>
      </div>

      {integrations.length === 0 ? (
        <p style={{ color: "var(--muted)" }}>No feeds added yet.</p>
      ) : (
        <ul style={{ listStyle: "none", padding: 0, display: "grid", gap: 8 }}>
          {integrations.map(ii => (
            <li key={ii.id} style={row}>
              <div style={{ display: "grid", gap: 4, minWidth: 260 }}>
                <strong>{ii.provider || "Unknown"}</strong>
                <small style={{ color: "var(--muted)", wordBreak: "break-all" }}>{ii.url}</small>
                {ii.last_sync && <small style={{ color: "var(--muted)" }}>Last sync: {new Date(ii.last_sync).toLocaleString()}</small>}
              </div>
              <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
                <label style={{ display: "flex", alignItems: "center", gap: 6, color: "var(--muted)", fontSize: 12 }}>
                  <input type="checkbox" checked={!!ii.is_active} onChange={() => onToggle(ii)} /> active
                </label>
                <button style={ghostBtn} onClick={() => onSync(ii.id)}>Sync now</button>
                <button style={dangerBtn} onClick={() => onDelete(ii.id)}>Delete</button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </InnerModal>
  );
}

/* ======= Styles ======= */
const panel: React.CSSProperties = {
  background: "var(--panel)", border: "1px solid var(--border)", borderRadius: 12, padding: 16, marginTop: 16,
};

const blueGrid: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fill, minmax(160px, 1fr))",
  gap: 12,
  alignItems: "stretch",
};

const blueTile: React.CSSProperties = {
  display: "grid",
  alignContent: "space-between",
  gap: 6,
  aspectRatio: "1 / 1",
  minHeight: 140,
  background: "var(--primary)",
  color: "#0c111b", // text foarte contrastant pe albastru
  border: "1px solid var(--border)",
  borderRadius: 12,
  padding: 12,
  textAlign: "left",
  cursor: "pointer",
  fontWeight: 700,
};

const tileTitle: React.CSSProperties = {
  fontSize: 16,
  lineHeight: 1.2,
  overflow: "hidden",
  textOverflow: "ellipsis",
  whiteSpace: "nowrap",
};

const tileSub: React.CSSProperties = {
  fontSize: 12,
  opacity: 0.85,
};

const row: React.CSSProperties = {
  display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12,
  background: "var(--panel)", border: "1px solid var(--border)", borderRadius: 12, padding: 12, flexWrap: "wrap"
};

const label: React.CSSProperties = { fontSize: 12, color: "var(--muted)" };

const input: React.CSSProperties = {
  padding: "8px 10px",
  background: "var(--bg)",
  color: "var(--text)",
  border: "1px solid var(--border)",
  borderRadius: 8,
};

const select: React.CSSProperties = {
  background: "var(--card)",
  color: "var(--text)",
  border: "1px solid var(--border)",
  padding: "6px 10px",
  borderRadius: 8,
  minWidth: 220,
};

const primaryBtn: React.CSSProperties = {
  padding: "8px 12px",
  borderRadius: 8,
  border: "none",
  background: "var(--primary)",
  color: "#0c111b",
  fontWeight: 800,
  cursor: "pointer",
};

const ghostBtn: React.CSSProperties = {
  padding: "6px 10px",
  borderRadius: 8,
  border: "1px solid var(--border)",
  background: "transparent",
  color: "var(--text)",
  fontWeight: 700,
  cursor: "pointer",
};

const dangerBtn: React.CSSProperties = {
  padding: "6px 10px",
  borderRadius: 8,
  border: "1px solid var(--danger)",
  background: "transparent",
  color: "var(--text)",
  fontWeight: 700,
  cursor: "pointer",
};

const miniPill: React.CSSProperties = {
  padding: "2px 8px",
  borderRadius: 999,
  background: "var(--card)",
  color: "var(--muted)",
  border: "1px solid var(--border)",
  fontSize: 12,
  fontWeight: 700,
};
