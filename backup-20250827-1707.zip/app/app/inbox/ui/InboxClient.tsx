"use client";

import { useEffect, useMemo, useState } from "react";
import { createClient } from "@/lib/supabase/client";

type Property = { id: string; name: string; check_in_time: string | null; check_out_time: string | null; };
type RoomType = { id: string; name: string; property_id: string };
type Room = { id: string; name: string; property_id: string; room_type_id: string | null };
type Unassigned = {
  id: string;
  property_id: string;
  room_type_id: string | null;
  uid: string | null;
  summary: string | null;
  start_date: string;
  end_date: string;
  start_time: string | null;
  end_time: string | null;
};

export default function InboxClient({ initialProperties }: { initialProperties: Property[] }) {
  const supabase = useMemo(() => createClient(), []);
  const [status, setStatus] = useState<"Idle"|"Loading"|"Error">("Idle");

  const [properties] = useState<Property[]>(initialProperties);
  const [propertyId, setPropertyId] = useState<string>(initialProperties[0]?.id ?? "");

  const [types, setTypes] = useState<RoomType[]>([]);
  const [rooms, setRooms] = useState<Room[]>([]);
  const [items, setItems] = useState<Unassigned[]>([]);
  const [assignSel, setAssignSel] = useState<Record<string, string>>({}); // eventId -> roomId

  useEffect(() => {
    if (!propertyId) return;
    setStatus("Loading");
    (async () => {
      const [rTypes, rRooms, rInbox] = await Promise.all([
        supabase.from("room_types").select("id,name,property_id").eq("property_id", propertyId).order("name", { ascending: true }),
        supabase.from("rooms").select("id,name,property_id,room_type_id").eq("property_id", propertyId).order("name", { ascending: true }),
        supabase.from("ical_unassigned_events")
          .select("id,property_id,room_type_id,uid,summary,start_date,end_date,start_time,end_time")
          .eq("property_id", propertyId)
          .order("start_date", { ascending: true })
      ]);
      if (rTypes.error || rRooms.error || rInbox.error) { setStatus("Error"); return; }
      setTypes((rTypes.data ?? []) as RoomType[]);
      setRooms((rRooms.data ?? []) as Room[]);
      setItems((rInbox.data ?? []) as Unassigned[]);
      setStatus("Idle");
    })();
  }, [propertyId, supabase]);

  const typeName = (tid: string | null) =>
    types.find(t => t.id === tid)?.name || (tid ? "Unknown type" : "—");

  async function doAssign(ev: Unassigned) {
    const roomId = assignSel[ev.id];
    if (!roomId) return;
    setStatus("Loading");
    const res = await fetch("/api/inbox/assign", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ eventId: ev.id, roomId })
    });
    if (res.ok) {
      setItems(prev => prev.filter(x => x.id !== ev.id));
      setStatus("Idle");
    } else {
      const j = await res.json().catch(() => ({}));
      alert(j?.error || "Failed to assign.");
      setStatus("Error");
    }
  }

  async function doDelete(ev: Unassigned) {
    if (!confirm("Delete this unassigned event?")) return;
    setStatus("Loading");
    const res = await fetch("/api/inbox/delete", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ eventId: ev.id })
    });
    if (res.ok) {
      setItems(prev => prev.filter(x => x.id !== ev.id));
      setStatus("Idle");
    } else {
      const j = await res.json().catch(() => ({}));
      alert(j?.error || "Failed to delete.");
      setStatus("Error");
    }
  }

  const pill = status === "Loading" ? "Syncing…" : status === "Error" ? "Error" : "Idle";

  return (
    <div style={{ display: "grid", gap: 16 }}>
      {/* Toolbar */}
      <div style={{ display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
        <span style={pillStyle(pill)}>{pill}</span>

        <select
          value={propertyId}
          onChange={(e) => setPropertyId(e.target.value)}
          style={{ background: "var(--card)", color: "var(--text)", border: "1px solid var(--border)", padding: "6px 10px", borderRadius: 8 }}
        >
          {properties.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
        </select>

        <span style={{ color: "var(--muted)", fontSize: 12 }}>
          Assign OTA room-type reservations to concrete rooms.
        </span>
      </div>

      {/* Grid de evenimente */}
      {items.length === 0 ? (
        <div style={{ color: "var(--muted)" }}>No unassigned events. You’re all set.</div>
      ) : (
        <ul style={{
          listStyle: "none", padding: 0,
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))",
          gap: 12
        }}>
          {items.map(ev => {
            const roomsOfType = rooms.filter(r => r.room_type_id && r.room_type_id === ev.room_type_id);
            return (
              <li key={ev.id} style={{ background: "var(--panel)", border: "1px solid var(--border)", borderRadius: 12, padding: 12, display: "grid", gap: 8 }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "start", gap: 8 }}>
                  <div style={{ display: "grid", gap: 2 }}>
                    <strong>{ev.summary || "Reservation"}</strong>
                    <small style={{ color: "var(--muted)" }}>
                      {ev.start_date} {ev.start_time || ""} → {ev.end_date} {ev.end_time || ""}
                    </small>
                    <small style={{ color: "var(--muted)" }}>
                      Type: {typeName(ev.room_type_id)} • UID: {ev.uid || "—"}
                    </small>
                  </div>
                  <a href="/app/calendar" style={{ color: "var(--primary)", textDecoration: "none" }}>Open calendar</a>
                </div>

                <div style={{ display: "grid", gap: 8, marginTop: 4 }}>
                  <div style={{ display: "grid", gap: 6 }}>
                    <label style={{ fontSize: 12, color: "var(--muted)" }}>Assign to room</label>
                    <select
                      value={assignSel[ev.id] || ""}
                      onChange={(e) => setAssignSel(prev => ({ ...prev, [ev.id]: e.target.value }))}
                      style={{ background: "var(--card)", color: "var(--text)", border: "1px solid var(--border)", padding: "6px 10px", borderRadius: 8 }}
                    >
                      <option value="">— select room —</option>
                      {roomsOfType.map(r => <option key={r.id} value={r.id}>{r.name}</option>)}
                    </select>
                  </div>

                  <div style={{ display: "flex", gap: 8 }}>
                    <button
                      onClick={() => doAssign(ev)}
                      disabled={!assignSel[ev.id]}
                      style={primaryBtn}
                    >
                      Assign
                    </button>
                    <button onClick={() => doDelete(ev)} style={dangerBtn}>Delete</button>
                  </div>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}

function pillStyle(pill: string): React.CSSProperties {
  const bg = pill === "Error" ? "var(--danger)" : pill === "Syncing…" ? "var(--primary)" : "var(--card)";
  const col = pill === "Idle" ? "var(--muted)" : "#0c111b";
  return { padding: "4px 10px", borderRadius: 999, background: bg, color: col, border: "1px solid var(--border)", fontWeight: 800, fontSize: 12 };
}
const primaryBtn: React.CSSProperties = {
  padding: "8px 12px", borderRadius: 10, border: "1px solid var(--border)",
  background: "var(--primary)", color: "#0c111b", fontWeight: 800, cursor: "pointer"
};
const dangerBtn: React.CSSProperties = {
  padding: "8px 12px", borderRadius: 10, border: "1px solid var(--danger)",
  background: "transparent", color: "var(--text)", fontWeight: 800, cursor: "pointer"
};
