import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import LoginClient from "./ui/LoginClient";

export default async function LoginPage() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (user) redirect("/app");

  return (
    <div style={{
      minHeight: "100vh",
      display: "grid",
      placeItems: "center",
      background: "var(--bg)",
      color: "var(--text)"
    }}>
      <LoginClient />
    </div>
  );
}
