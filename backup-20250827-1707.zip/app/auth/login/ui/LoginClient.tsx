"use client";

import { useEffect, useState } from "react";

export default function LoginClient() {
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  const [status, setStatus] = useState<"Idle"|"Loading"|"Error">("Idle");
  const [err, setErr] = useState<string>("");

  // Arătăm erorile venite ca query (ex. din callback)
  useEffect(() => {
    const u = new URL(window.location.href);
    const e = u.searchParams.get("error");
    if (e) {
      setErr(decodeURIComponent(e));
      setStatus("Error");
    }
  }, []);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setStatus("Loading"); setErr("");
    const res = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password: pass })
    });
    if (res.ok) {
      location.href = "/app";
    } else {
      const j = await res.json().catch(() => ({}));
      setErr(j?.error || "Invalid credentials.");
      setStatus("Error");
    }
  }

  function signInWithGoogle() {
    // pornim flow-ul pe server; acesta redirecționează către Google
    window.location.href = "/auth/oauth/google";
  }

  const pill = status === "Loading" ? "Signing in…" : status === "Error" ? "Error" : "Idle";

  return (
    <div style={{
      width: 380,
      background: "var(--panel)",
      border: "1px solid var(--border)",
      borderRadius: 12,
      padding: 18,
      boxShadow: "0 10px 30px rgba(0,0,0,0.25)"
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
        <h1 style={{ margin: 0, fontSize: 18 }}>Login</h1>
        <span style={pillStyle(pill)}>{pill}</span>
      </div>

      <div style={{ display: "grid", gap: 10 }}>
        <button
          onClick={signInWithGoogle}
          style={{
            padding: "10px 14px",
            borderRadius: 10,
            border: "1px solid var(--border)",
            background: "var(--card)",
            color: "var(--text)",
            fontWeight: 800,
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 10
          }}
        >
          <img
            src="/google.png"
            alt="Google"
            width={20}
            height={20}
            style={{ display: "block" }}
          /> Continue with Google
        </button>

        <div style={{ display: "grid", gridTemplateColumns: "1fr auto 1fr", alignItems: "center", gap: 8 }}>
          <span style={{ height: 1, background: "var(--border)", display: "block" }} />
          <small style={{ color: "var(--muted)" }}>or</small>
          <span style={{ height: 1, background: "var(--border)", display: "block" }} />
        </div>

        <form onSubmit={onSubmit} style={{ display: "grid", gap: 10 }}>
          <div style={{ display: "grid", gap: 6 }}>
            <label style={lbl}>Email</label>
            <input
              type="email"
              value={email}
              onChange={(e)=>setEmail(e.currentTarget.value)}
              placeholder="you@example.com"
              style={input}
              required
            />
          </div>
          <div style={{ display: "grid", gap: 6 }}>
            <label style={lbl}>Password</label>
            <input
              type="password"
              value={pass}
              onChange={(e)=>setPass(e.currentTarget.value)}
              placeholder="••••••••"
              style={input}
              required
            />
          </div>

          {err && <div style={{ color: "var(--danger)", fontSize: 13 }}>{err}</div>}

          <button
            type="submit"
            disabled={!email || !pass || status==="Loading"}
            style={primaryBtn}
          >
            Sign in
          </button>

          <small style={{ color: "var(--muted)" }}>
          </small>
        </form>
      </div>
    </div>
  );
}

const input: React.CSSProperties = {
  padding: "10px 12px",
  background: "var(--bg)",
  color: "var(--text)",
  border: "1px solid var(--border)",
  borderRadius: 8
};
const lbl: React.CSSProperties = { fontSize: 12, color: "var(--muted)" };
const primaryBtn: React.CSSProperties = {
  padding: "10px 14px",
  borderRadius: 10,
  border: "1px solid var(--border)",
  background: "var(--primary)",
  color: "#0c111b",
  fontWeight: 800,
  cursor: "pointer"
};
function pillStyle(pill: string): React.CSSProperties {
  const bg = pill === "Error" ? "var(--danger)" : pill === "Signing in…" ? "var(--primary)" : "var(--card)";
  const col = pill === "Idle" ? "var(--muted)" : "#0c111b";
  return { padding: "4px 10px", borderRadius: 999, background: bg, color: col, border: "1px solid var(--border)", fontWeight: 800, fontSize: 12 };
}
