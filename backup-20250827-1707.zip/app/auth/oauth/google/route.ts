import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function GET(req: Request) {
  const supabase = createClient();
  const url = new URL(req.url);
  const origin = url.origin;

  // După login, mergem la /app (poți schimba în /app/calendar etc.)
  const redirectTo = `${origin}/auth/callback?next=/app`;

  const { data, error } = await supabase.auth.signInWithOAuth({
    provider: "google",
    options: { redirectTo }
  });

  if (error || !data?.url) {
    const msg = encodeURIComponent(error?.message ?? "OAuth start failed");
    return NextResponse.redirect(new URL(`/auth/login?error=${msg}`, req.url));
  }

  // Trimite user-ul spre Google
  return NextResponse.redirect(data.url);
}
