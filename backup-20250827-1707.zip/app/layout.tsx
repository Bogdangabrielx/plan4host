export const metadata = { title: "Plan4Host MVP" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ro">
      <body
        style={{
          margin: 0,
          fontFamily:
            "system-ui, -apple-system, Segoe UI, Roboto, Ubuntu, Cantarell, Noto Sans, sans-serif",
          // 🎨 Paleta globală (dark)
          // Fundal
          background: "#0f1115",
          // Text
          color: "#e5e7eb",
          // CSS vars
          // straturi
          // @ts-expect-error CSS vars
          "--bg": "#0f1115",
          // @ts-expect-error CSS vars
          "--panel": "#171a21",
          // @ts-expect-error CSS vars
          "--card": "#0e1117",
          // @ts-expect-error CSS vars
          "--border": "#242833",
          // text
          // @ts-expect-error CSS vars
          "--text": "#e5e7eb",
          // @ts-expect-error CSS vars
          "--muted": "#9aa4b2",
          // stări
          // @ts-expect-error CSS vars
          "--primary": "#6ea8fe",
          // @ts-expect-error CSS vars
          "--success": "#51d17a",
          // @ts-expect-error CSS vars
          "--danger": "#ff6b6b"
        } as React.CSSProperties}
      >
        {children}
      </body>
    </html>
  );
}
